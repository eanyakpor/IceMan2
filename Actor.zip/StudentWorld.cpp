#include "StudentWorld.h"
#include "GraphObject.h"
#include "Actor.h"

#include <string>
#include <vector>
#include <memory>
#include <math.h> 
#include <time.h>
using namespace std;

//void makeIceField();

GameWorld* createStudentWorld(string assetDir)
{
    return new StudentWorld(assetDir);
}

void StudentWorld::removeIce()
{
    
    int x = IceMn->getX();
    int y = IceMn->getY();
   
    
    for (int i = 0; i < 60; i++) // column
    {
        for (int j = 0; j < 60; j++) //row
        {
            if (j > 29 && j < 32 && i > 3)
            {
                j += 4;
            }
            if (Ice1[j][i] == Ice1[x][y])
            {
                //if (Ice1[y][x] != Ice1[60][60])//&& Ice1[y][x] != Ice1[64][x] && Ice1[y][x] != Ice1[y][64]
                //{
                if (Ice1[y][x] != NULL)
                {
                    delete Ice1[y][x];// this is not dynamically allocating 
                    Ice1[y][x] = NULL;
                    return;
                }
                    
                //}
                   /* if (Ice1[y][x] == Ice1[60][60])
                {
                   Ice** Ice1 = new Ice * [200];
                }*/
                
            }
        }
    }
}


int StudentWorld::init()
{
   
    
   // StudentWorld* s = 0;
    GraphObject::Direction dr = GraphObject::Direction::down;// forthe iceman
    IceMn = unique_ptr<IceMan>(new IceMan(IID_PLAYER, 30, 60, dr, this));
   //IceMn->setVisible(true);



    //  nugget = unique_ptr<gold>(new gold(IID_GOLD, 20, 20, dr, 1));
     // nugget->setVisible(true);
      // which way should i implement it? Should i create the ice first, then create the boulders and delete the ice underneath it, or should i create the boulders then place the ice around the boulders
      // I had trouble not getting ice in the center toyed with the x and y values, made the mistake of changing the y instead of x values when it came to putting objects in the field


    int current_level_number = 0;
    int b = 2, n = 5, ba = 2, i = 0;// j = 0, k = 0;
    int y1;
    int x3;
    vector<pair<int, int>> xyHolder;
    vector<boulder*>bolda;
    vector<gold*>nuggets;
    vector<barrel*>barrels;
    int coordTracker = 0; // keeps track of how many objects were put into xyholder in order to go thru all of the elements necessary
    dr = GraphObject::Direction::down;// for the boulders
    while (i != b)
    {
        std::srand((unsigned)time(0));
        do
        {
            int x1 = (rand() % (56 - 4 + 1)) + 4;
            x3 = x1;
        } while (x3 >= 26 && x3 <= 34);//(x3 <= 4 || (x3 >= 26 && x3 <= 34) || x3 >= 56);


        int y1 = (rand() % (56 - 20 + 1)) + 20;


        if (xyHolder.empty())
        {
            xyHolder.push_back(make_pair(x3, y1));
            bolda.push_back(new boulder(IID_BOULDER, x3, y1, dr, this, 1, 1));
            bolda.at(0)->setVisible(true);

            i += 1;
            /// to not let teh boulders spawn in the middle line maybe a while this is not   
        }
        else
        {
            for (int z = 0; z < xyHolder.size(); z++)
            {
                if (distanceFormula(x3, y1, xyHolder.at(z).first, xyHolder.at(z).second) >= 6)
                {
                    coordTracker += 1;
                    if (coordTracker == xyHolder.size())
                    {
                        xyHolder.push_back(make_pair(x3, y1));
                        bolda.push_back(new boulder(IID_BOULDER, x3, y1, dr, this, 1, 1));
                        bolda.at(coordTracker)->setVisible(true);
                        i += 1;
                    }
                }
                //if (distanceFormula(x3,y1,z.first, z.second) >= 6 )//&& distanceFormula(x3, y1, z.first, z.second) != 0 not needed 
                //{
                //    xyHolder.push_back(make_pair(x3, y1));
                //    b1 = unique_ptr<boulder>(new boulder(IID_BOULDER, x3, y1, dr, 1, 1));
                //    b1->setVisible(true);
                //    bolda.push_back(b1);
                //    //create the object at this position, do i have to name the object to set it visible?
                //    i += 1;
                //}
            }
        }

    }

    dr = GraphObject::Direction::right;
    //making the ice
    for (int i = 0; i < 60; i++) // column
    {
        for (int j = 0; j < 60; j++) //row
        {
            if (j > 29 && j < 32 && i > 3)
            {
                j += 4;
            }
            if ((bolda.at(0)->getY() == i && bolda.at(0)->getX() == j) || bolda.at(0)->getY() + 1 == i && bolda.at(0)->getX() == j ||
                bolda.at(0)->getY() + 2 == i && bolda.at(0)->getX() == j || (bolda.at(0)->getY() + 3 == i && bolda.at(0)->getX() == j) ||
                (bolda.at(1)->getY() == i && bolda.at(1)->getX() == j) || (bolda.at(1)->getY() + 1 == i && bolda.at(1)->getX() == j) ||
                (bolda.at(1)->getY() + 2 == i && bolda.at(1)->getX() == j) || (bolda.at(1)->getY() + 3 == i && bolda.at(1)->getX() == j))
            {
                if ((bolda.at(0)->getY() >= 56 && j >= 56) || (bolda.at(1)->getY() >= 56 && j >= 56)) {
                    break;
                }
                else {
                    j += 4;
                }
            }
            Ice1[i][j] = new Ice(IID_ICE, j, i, dr, this, .25, 3);
            //Ice1[i][j]->setVisible(true);

        }
    }

    //   ---------------------------------------------------------------------------------------------

    i = 0;
    coordTracker = 0;
    int nuggetCount = 0;
    while (i != n) {
        while (i != n)
        {
            coordTracker = 0;
            std::srand((unsigned)time(0));
            do
            {
                int x1 = (rand() % (56 - 4 + 1)) + 4;
                x3 = x1;
            } while (x3 >= 26 && x3 <= 34);

            int y1 = rand() % 56;

            for (int z = 0; z < xyHolder.size(); z++)
            {
                if (distanceFormula(x3, y1, xyHolder.at(z).first, xyHolder.at(z).second) >= 6 && distanceFormula(x3, y1, xyHolder.at(z).first, xyHolder.at(z).second) != 0)
                {
                    coordTracker += 1;
                    if (coordTracker == xyHolder.size())
                    {
                        xyHolder.push_back(make_pair(x3, y1));
                        nuggets.push_back(new gold(IID_GOLD, x3, y1, dr, this, 1, 0));
                        // nuggets.at(nuggetCount)->setVisible(false);
                        nuggetCount += 1;
                        i += 1;
                        break;
                    }
                }

            }


        }

    }

    i = 0;
    coordTracker = 0;
    int barrelCount = 0;
    while (i != n) {
        while (i != n)
        {
            coordTracker = 0;
            std::srand((unsigned)time(0));
            do
            {
                int x1 = (rand() % (56 - 4 + 1)) + 4;
                x3 = x1;
            } while (x3 >= 26 && x3 <= 34);
            int y1 = rand() % 56;

            for (int z = 0; z < xyHolder.size(); z++)
            {
                if (distanceFormula(x3, y1, xyHolder.at(z).first, xyHolder.at(z).second) >= 6 && distanceFormula(x3, y1, xyHolder.at(z).first, xyHolder.at(z).second) != 0)
                {
                    coordTracker += 1;
                    if (coordTracker == xyHolder.size())
                    {
                        xyHolder.push_back(make_pair(x3, y1));
                        barrels.push_back(new barrel(IID_BARREL, x3, y1, dr, this, 1, 00));
                        // barrels.at(barrelCount)->setVisible(false);
                        barrelCount += 1;
                        i += 1;
                        break;
                    }
                }

            }


        }

    }
    return GWSTATUS_CONTINUE_GAME;
}
int StudentWorld::move()
{
    IceMn->doSomething();
    return GWSTATUS_CONTINUE_GAME;
}
void StudentWorld::cleanUp()
{
   
        for (int i = 0; i < 60; i++) // column
        {
            for (int j = 0; j < 60; j++) //row
            {
                if (j > 29 && j < 32 && i > 3)
                {
                    j += 4;
                }
                delete Ice1[j][i];
                Ice1[j][i] = nullptr;
                return;
            }
        }
         IceMn.reset();
 }
    

//StudentWorld* StudentWorld::getWorld() { return this; };


//-------------------------------------------------------------------------------------------------------------------------

// I had to create nugget counter/ barrel counter to display the current nugget that I was at because if I used coordTracker it would be incremented one more 
    //than the object that I was in in it's container and I would get a loop where the same object was being printed on the same spot
    //I had to tinker around with rand to get it to give me the proper range ended up finding the formula (rand() % (max - min + 1)) + min;, anlso needed std::srand((unsigned)time(0));
//for (int  j = 0; j < i; j++)
//{
//
//}

//int distanceFormula(int xx1, int yy1, int xx2, int yy2) {
//    int x3 = xx1, y1 = yy1, x2 = xx2, y2 = yy2, result;
//    result = sqrt((x2 - x3) ^ 2 + (y2 - y1) ^ 2);
//    return result;
//}
//void iceField() {
//    GraphObject::Direction dr = GraphObject::Direction::right;
//
//    for (int i = 0; i < 60; i++) // rows
//    {
//        for (int j = 0; j < 60; j++) //colums
//        {
//            if (j > 25 && j < 30)
//            {
//                j += 8;
//            }
//            Ice1[i][j] = new Ice(IID_ICE, j, i, dr);
//            Ice1[i][j]->setVisible(true);
//
//        }
//    }
//}
//void StudentWorld::makeIceField() {}
// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
