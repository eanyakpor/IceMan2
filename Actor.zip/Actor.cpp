#include "Actor.h"
#include "StudentWorld.h"
#include <math.h> 
#include "GameWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp
//Ice::Ice(int Xpos, int Ypos);
//void doSomething();

//Ice(int startX, int startY) :  Actor(IID_ICE, startX, startY, right, nullptr, .25, 0) {}

//Actor::Actor(int imageID, int startX, int startY, Direction startDirection, float size, unsigned int depth) : GraphObject(imageID, startX, startY, startDirection, size, depth) {}
////
//Ice::Ice(int imageID, int startX, int startY, Direction startDirection, float size, unsigned int depth ) : Actor(imageID, startX, startY, startDirection, size, depth) {}

void Ice::doSomething() {}



void IceMan::doSomething()
{
    //enum Direction { none, up, down, left, right };
    GraphObject::Direction dn = GraphObject::Direction::down;
    GraphObject::Direction up = GraphObject::Direction::up;
    GraphObject::Direction lt = GraphObject::Direction::left;
    GraphObject::Direction rt = GraphObject::Direction::right;
    int ch;
    int Dcount = 60;
    int Lcount = 30;
    int Rcount = 30;
    int Upcount = 60;
    if (getWorld()->getKey(ch) == true) 
    {  // user hit a key this tick! 
        switch (ch)
        {
            //col,row
        case KEY_PRESS_DOWN:
            // need to some how check if its ice than its blocked and you can't go in that direction 
            //need to be able to destory ice so i can dig through it 
            GraphObject::setDirection(dn);
           
           // Dcount -= 1;
            moveTo(getX(), getY()-1);
            getWorld()->removeIce();
            break;

        case KEY_PRESS_UP: //works
           // Upcount += 1;
            GraphObject::setDirection(up);
            moveTo(getX(), 1+getY());
            getWorld()->removeIce();
            break;


        case KEY_PRESS_LEFT:
           // Lcount -= 1;
            GraphObject::setDirection(lt);
            moveTo(getX()-1, getY());
            getWorld()->removeIce();
            break;


        case KEY_PRESS_RIGHT: //works
            //Rcount += 1;
            GraphObject::setDirection(rt);
            moveTo(getX()+1, getY());
            getWorld()->removeIce();
            break;
        }
    }

}

void boulder::doSomething() {}

void gold::doSomething() {}

void barrel::doSomething() {}

void waterPool::doSomething() {}



//
//
//Pedestrian::Pedestrian(StudentWorld* world, int startX, int startY, int imageID, int startDirection, double size, int depth,
//	bool alive, int health, bool avoidanceWorthy, int yVel, int xVel, int movePlan)
//	: Actor(world, imageID, startX, startY, startDirection, size, depth, alive, health, avoidanceWorthy, yVel, xVel),