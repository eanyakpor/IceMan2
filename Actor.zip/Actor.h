#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <math.h> 

//class Actor : public GraphObject {
//public:
//	Actor(int imageID, int startX, int startY, Direction startDirection, float size = 1.0, unsigned int depth = 0);
//	//Actor();
//	~Actor() {};
//
//	//void doSomething() {};
//	
//};
//forward decleration
class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld *sw, double size = 1.0, unsigned int depth = 0)
		: GraphObject(img_id, m_x, m_y, dr, size, depth) 
	{
		p = sw;
	}
	virtual void doSomething() = 0;

	StudentWorld* getWorld()
	{
		return p;
	}
	//virtual ~Actor();

private:
	StudentWorld* p;

};
//class Iceman : public Actor/* : public ...*/ {
//public:
//	virtual void doSomething() {
//
//		//Try to get user input(if any is available)  If the user pressed the UP keyand that square is open then
//		//	Increase my y location by one
//		//	If the user pressed the DOWN keyand that square is open then
//		//		Decrease my y location by one
//		//	...  If the user pressed the space bar to fireand the Iceman has
//		//	water, then
//		//	Introduce a new Squirt object into the game facing the same
//		//	direction as the player
//		//	...
//	}
//};
class StudentWorld;
class IceMan : public Actor
{
public:
	IceMan(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld *sw, double size = 1.0, unsigned int depth = 0)
		: Actor(IID_PLAYER, m_x, m_y, dr, sw, size, depth) 
	{
		setVisible(true);
	}
	void doSomething();
	
	//~IceMan();
};

class Ice : public Actor
{
public:
	Ice(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld* sw, double size = 1.0, unsigned int depth = 0)
		: Actor(IID_ICE, m_x, m_y, dr, sw, size, depth) 
	{
		setVisible(true);
	}
	void doSomething();
	//~Ice();
};

class Goodie : public Actor
{
public:
	Goodie(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld* sw, double size = 1.0, unsigned int depth = 0)
		: Actor(img_id, m_x, m_y, dr, sw, size, depth) {}
	virtual void doSomething() = 0;
};

class gold : public Goodie
{
public:
	gold(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld* sw, double size = 1.0, unsigned int depth = 0)
		: Goodie(img_id, m_x, m_y, dr, sw, size, depth) {}
	void doSomething();
};

class boulder : public Actor
{
public:
	boulder(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld* sw, double size = 1.0, unsigned int depth = 0)
		: Actor(img_id, m_x, m_y, dr, sw, size, depth) {}
	void doSomething();

	
};

class barrel : public Goodie
{
public:
	barrel(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld* sw, double size = 1.0, unsigned int depth = 0)
		: Goodie(img_id, m_x, m_y, dr, sw, size, depth) {}
	void doSomething();
};

class waterPool : public Goodie
{
public:
	waterPool(int img_id, int m_x, int m_y, GraphObject::Direction dr, StudentWorld* sw, double size = 1.0, unsigned int depth = 0)
		: Goodie(img_id, m_x, m_y, dr, sw, size, depth) {}
	void doSomething();
};

//public:
	//Ice(int y, int x) {};
	//~Ice();
	//void doSomething();
	//bool setVisible() { return true; }
	/* THIS IS THE BASIS FOR EACH CLASS, 1:WHAT DOES IT DO WHEN CREATED. 2:WHAT DOES IT DO DURING A TICK. 3:WHAT DOES IT DO WHEN IT IS ANNOYED
	What the Iceman Must Do During a Tick ............................................................................................................ 27
	What the Iceman Must Do When It Is Annoyed ............................................................................................... 29
	Getting Input From the User ........*/
	//};

	//class Water refills  : public Actor {/**/};
	//class Boulders : public Actor {/**/};
	//class Squirt : public Actor {/**/ };
	//class barrelofOil : public Actor {/**/ };
	//class goldNugget : public Actor {/**/ };
	//class sonarKit : public Actor {/**/ };
	//class waterPool : public Actor {/**/ };
	//class regularProtestor : public Actor {/*
	//	public:
	//		virtual void doSomething() {
	//			If I am facing the Iceman and he is next to me, then
	//				Shout at the Iceman (to annoy him)
	//
	//			Else if the Iceman is visible via direct line of sight, then
	//				Switch direction to face the Iceman  Move one square in this direction  Else if I�m about to run into an obstacle, then
	//				Pick a new direction
	//				Move one square in this direction
	//			Else  Move one square in my current direction  }
	//...  };
	//A*/};
	//class hardcoreProtestor: public regularProtestor{/**/ };


	// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // ACTOR_H_
