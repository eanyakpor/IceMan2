#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <memory>
#include <math.h> 


// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	//Ice* myIce;
	Ice* Ice1[64][64];
	std::unique_ptr<gold> nugget;
	std::unique_ptr<IceMan> IceMn;
	std::unique_ptr<boulder>  b1;




	

	StudentWorld(std::string assetDir)
		: GameWorld(assetDir)
	{
	}

	//StudentWorld* getWorldPointer() {
	//	StudentWorld* swP = this;
	//	return swP;
	//};

	virtual int init();

	virtual int move();
		// This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
		// Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
		//decLives();;
		//makeIce();
		
	

	virtual void cleanUp();

	int distanceFormula(int xx1, int yy1, int xx2, int yy2) {
		int x1 = xx1, y1 = yy1, x2 = xx2, y2 = yy2, result;

		result = sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
		return result;
	}
	void removeIce();

	/*void setDisplayText()
{   int level = getCurrentGameLevel();
int lives = getNumLivesLeft();
int health = getCurrentHealth();
int squirts = getSquirtsLeftInSquirtGun();
int gold = getPlayerGoldCount();
int barrelsLeft = getNumberOfBarrelsRemainingToBePickedUp();
22

int sonar = getPlayerSonarChargeCount();  int score = getCurrentScore();
 //  Next, create a string from your statistics, of the form:  // Lvl: 52 Lives: 3 Hlth: 80% Wtr: 20 Gld: 3 Oil Left: 2 Sonar: 1 Scr: 321000

string s = someFunctionYouUseToFormatThingsNicely(level, lives, health,
squirts, gold, barrelsLeft, sonar, score);  //  Finally, update the display text at the top of the screen with your  //  newly created stats
setGameStatText(s); // calls our provided GameWorld::setGameStatText  } */

//void makeIce(){
	//myIce = 
	//Ice Ice1(imageID, startX, startY, Ice::right, size, depth);
	//Actor A1(imageID, startX =10, startY = 5, Actor::right, size, depth);
	//A1.setVisible(true);
//	Ice()
//	for (int i = 0; i < VIEW_HEIGHT; i++)
//	{
//		for (int j = 0; j < VIEW_WIDTH; j++)
//		{
//			iceField[i][j] = std::unique_ptr<Ice>(new Ice( IID_ICE, i, j, 0, 0.25, 0));
//		}
//	}
//}
	virtual ~StudentWorld()
	{
		this->cleanUp();
	}

};

#endif // STUDENTWORLD_H_

